import { useState } from 'react'

export default function App() {
  const [poules, setPoules] = useState(1100)
  const [oeufs, setOeufs] = useState(0)
  const [depenses, setDepenses] = useState(0)

  const plateaux = oeufs / 30
  const recettes = plateaux * 45000
  const benefice = recettes - depenses
  const taux = poules === 0 ? 0 : (oeufs / poules) * 100

  return (
    <div style={{ padding: 20, fontFamily: 'Arial' }}>
      <h1>🐔 FERME AVICOLE ESPOIR</h1>
      <h2>ERP Gestion Poules Pondeuses</h2>

      <div>
        <p>Poules vivantes :</p>
        <input type="number" value={poules} onChange={e => setPoules(Number(e.target.value))} />
      </div>

      <div>
        <p>Œufs collectés aujourd'hui :</p>
        <input type="number" value={oeufs} onChange={e => setOeufs(Number(e.target.value))} />
      </div>

      <div>
        <p>Dépenses du jour :</p>
        <input type="number" value={depenses} onChange={e => setDepenses(Number(e.target.value))} />
      </div>

      <hr />

      <p>Plateaux : {plateaux.toFixed(2)}</p>
      <p>Taux de ponte : {taux.toFixed(2)} %</p>
      <p>Recettes : {recettes.toLocaleString()} GNF</p>
      <h3>Bénéfice net : {benefice.toLocaleString()} GNF</h3>
    </div>
  )
}
